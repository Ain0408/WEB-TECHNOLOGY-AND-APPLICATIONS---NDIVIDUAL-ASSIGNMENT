<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$sql = "SELECT * FROM movies WHERE user_id = ? ORDER BY created_at DESC";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i", $user_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Dashboard - Movie Watchlist</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background: linear-gradient(135deg, #0a0a0a, #1b0036);
      color: white;
      font-family: 'Segoe UI', sans-serif;
      padding: 30px;
    }

    .header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 40px;
    }

    .header h2 {
      color: #cc66ff;
    }

    .header a {
      color: white;
      background: #cc66ff;
      padding: 10px 20px;
      border-radius: 8px;
      text-decoration: none;
      transition: 0.3s;
    }

    .header a:hover {
      background: #a64dff;
    }

    .movie-list {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
      gap: 20px;
    }

    .movie-card {
      background: rgba(255, 255, 255, 0.08);
      border-radius: 15px;
      padding: 20px;
      box-shadow: 0 4px 15px rgba(204, 102, 255, 0.1);
      backdrop-filter: blur(10px);
      transition: 0.3s ease;
      display: flex;
      flex-direction: column;
      align-items: center;
    }

    .movie-card:hover {
      transform: scale(1.02);
      box-shadow: 0 4px 20px rgba(204, 102, 255, 0.3);
    }

    .movie-card img {
      max-width: 100%;
      border-radius: 12px;
      margin-bottom: 15px;
      max-height: 300px;
      object-fit: cover;
      box-shadow: 0 0 10px rgba(204, 102, 255, 0.6);
    }

    .movie-card h3 {
      color: #cc66ff;
      margin-bottom: 10px;
      text-align: center;
    }

    .movie-card p {
      color: #ccc;
      font-size: 14px;
      margin: 4px 0;
      text-align: center;
    }

    .movie-card .actions {
      margin-top: 15px;
    }

    .movie-card .actions a {
      color: #cc66ff;
      margin-right: 10px;
      text-decoration: none;
      font-weight: bold;
    }

    .movie-card .actions a:hover {
      text-decoration: underline;
    }

    .watch-button {
      display: inline-block;
      padding: 10px 16px;
      background-color: #9b59b6;
      color: white;
      border: none;
      border-radius: 6px;
      text-decoration: none;
      font-weight: bold;
      transition: background-color 0.3s;
      margin-top: 8px;
    }

    .watch-button:hover {
      background-color: #8e44ad;
    }
    .watch-button.netflix {
      background-color: #e50914;
    }

    .watch-button.youtube {
      background-color: #ff0000;
    }

    .watch-button.disney {
      background-color: #113ccf;
    }

    .watch-button.imdb {
      background-color: #f5c518;
      color: black;
    }

    .watch-button:hover {
      filter: brightness(1.1);
    }
  </style>
</head>
<body>

  <div class="header">
    <h2>Welcome, <?php echo htmlspecialchars($_SESSION['email']); ?>!</h2>
    <div>
      <a href="add_movie.php">+ Add New Movie</a>
      <a href="logout.php" style="margin-left: 10px; background: #800080;">Logout</a>
    </div>
  </div>

  <h3 style="color: #fff;">Your Movie Watchlist:</h3>

  <div class="movie-list">
    <?php while ($movie = mysqli_fetch_assoc($result)): ?>
      <div class="movie-card">
        <?php if (!empty($movie['image_url'])): ?>
          <img src="<?php echo htmlspecialchars($movie['image_url']); ?>" alt="<?php echo htmlspecialchars($movie['title']); ?> poster">
        <?php endif; ?>
        <h3><?php echo htmlspecialchars($movie['title']); ?></h3>
        <p><strong>Genre:</strong> <?php echo htmlspecialchars($movie['genre']); ?></p>
        <p><strong>Status:</strong> <?php echo $movie['status']; ?></p><p><strong>Rating:</strong> <?php echo $movie['rating'] ? str_repeat("★", $movie['rating']) : '-'; ?></p>
        <p><strong>Notes:</strong> <?php echo nl2br(htmlspecialchars($movie['notes'])); ?></p>

        <?php if (!empty($movie['link'])): ?>
        <?php 
          $parsed_url = parse_url($movie['link']);
          $host = strtolower($parsed_url['host'] ?? '');
          $label = 'Watch Here';
          $buttonClass = 'watch-button';

          if (strpos($host, 'netflix') !== false) {
              $label = 'Watch on Netflix';
              $buttonClass .= ' netflix';
          } elseif (strpos($host, 'youtube') !== false) {
              $label = 'Watch on YouTube';
              $buttonClass .= ' youtube';
          } elseif (strpos($host, 'disney') !== false) {
              $label = 'Watch on Disney+';
              $buttonClass .= ' disney';
          } elseif (strpos($host, 'imdb') !== false) {
              $label = 'View on IMDb';
              $buttonClass .= ' imdb';
          }
        ?>
        <a href="<?php echo htmlspecialchars($movie['link']); ?>" target="_blank" class="<?php echo $buttonClass; ?>">
            <?php echo $label; ?>
        </a>
        <?php endif; ?>

        <div class="actions">
          <a href="edit_movie.php?id=<?php echo $movie['id']; ?>">Edit</a>
          <a href="delete_movie.php?id=<?php echo $movie['id']; ?>" onclick="return confirm('Are you sure?')">Delete</a>
        </div>
      </div>
    <?php endwhile; ?>
  </div>

</body>
</html>