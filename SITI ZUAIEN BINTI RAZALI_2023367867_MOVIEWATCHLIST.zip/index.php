<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Movie Watchlist</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body, html {
      height: 100%;
      margin: 0;
      font-family: 'Segoe UI', sans-serif;
      color: #fff;
    }

    body {
  background-image: url('https://www.freepik.com/free-photo/empty-cinema-hall-red-seats_1063122.htm');
  background-size: cover;
  background-position: center;
  background-attachment: fixed;
}


    .overlay {
      background: rgba(0, 0, 0, 0.8);
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      display: flex;
      flex-direction: column;
    }

    .header {
      background-color: #4b0082;
      padding: 20px 40px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      z-index: 2;
    }

    .logo {
      font-size: 32px;
      font-weight: bold;
      color: #fff;
      text-transform: uppercase;
      letter-spacing: 2px;
      text-decoration: none;
    }

    .btn-register {
      background: transparent;
      border: 2px solid #cc66ff;
      color: #cc66ff;
      padding: 8px 20px;
      font-size: 16px;
      border-radius: 30px;
      text-decoration: none;
      transition: 0.3s ease-in-out;
    }

    .btn-register:hover {
      background-color: #cc66ff;
      color: #fff;
      transform: scale(1.05);
    }

    .main-content {
      flex: 1;
      display: flex;
      justify-content: center;
      align-items: center;
      padding: 20px;
    }

    .glass-card {
      background: rgba(255, 255, 255, 0.05);
      border-radius: 20px;
      padding: 40px;
      max-width: 600px;
      width: 100%;
      text-align: center;
      backdrop-filter: blur(15px);
      -webkit-backdrop-filter: blur(15px);
      border: 1px solid rgba(255, 255, 255, 0.1);
      box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
    }

    .glass-card h1 {
      font-size: 48px;
      color: #cc99ff;
      text-shadow: 0 0 10px #a64dff;
      margin-bottom: 20px;
    }

    .glass-card p {
      font-size: 20px;
      color: #e0d3ff;
      margin-bottom: 40px;
    }

    .btn-login {
      background: linear-gradient(135deg, #a64dff, #cc66ff);
      color: white;
      border: none;
      padding: 14px 36px;
      font-size: 18px;
      border-radius: 30px;
      transition: 0.3s ease-in-out;
      box-shadow: 0 4px 15px rgba(204, 102, 255, 0.4);
      text-decoration: none;
    }

    .btn-login:hover {
      transform: scale(1.05);
      box-shadow: 0 6px 20px rgba(204, 102, 255, 0.6);
    }
  </style>
</head>
<body>

  <div class="bg-image">
    <div class="overlay">

      <header class="header">
        <a href="#" class="logo">Movie Watchlist</a>
        <a href="register.php" class="btn-register">Register</a>
      </header>

      <section class="main-content">
        <div class="glass-card">
          <h1>Manage Your Movies Like a Pro</h1>
          <p>Keep track of what you want to watch and rate the movies you've seen all in one stylish list.</p>
          <a href="login.php" class="btn-login">Login</a>
        </div>
      </section>

    </div>
  </div>

</body>
</html>