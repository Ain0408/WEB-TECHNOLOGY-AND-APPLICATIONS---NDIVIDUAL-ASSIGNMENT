<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$message = '';

if (!isset($_GET['id'])) {
    header("Location: dashboard.php");
    exit;
}

$movie_id = intval($_GET['id']);

$sql = "SELECT * FROM movies WHERE id = ? AND user_id = ?";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "ii", $movie_id, $user_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if (!$movie = mysqli_fetch_assoc($result)) {
    header("Location: dashboard.php");
    exit;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = trim($_POST['title']);
    $genre = trim($_POST['genre']);
    $status = $_POST['status'];
    $rating = $_POST['rating'];
    $notes = trim($_POST['notes']);
    $link = trim($_POST['link']);
    $image_url = trim($_POST['image_url']); 
   
    if (empty($title)) {
        $message = "Title is required.";
    } else {
        $update_sql = "UPDATE movies SET title=?, genre=?, status=?, rating=?, notes=?, link=?, image_url=? WHERE id=? AND user_id=?";
        $stmt = mysqli_prepare($conn, $update_sql);
        mysqli_stmt_bind_param($stmt, "sssisssii", $title, $genre, $status, $rating, $notes, $link, $image_url, $movie_id, $user_id);

        if (mysqli_stmt_execute($stmt)) {
            header("Location: dashboard.php");
            exit;
        } else {
            $message = "Error updating movie.";
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Movie - Movie Watchlist</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css" />
</head>
<body>
        <div class="editmovie-container">
            <h2>Edit Movie</h2>

            <?php if ($message): ?>
                <div class="alert alert-danger"><?php echo $message; ?></div>
            <?php endif; ?>

            <form method="POST">
                <div class="mb-3">
                    <label class="form-label">Title</label>
                    <input type="text" class="form-control" name="title" value="<?php echo htmlspecialchars($movie['title']); ?>" required>
                </div>

                <div class="mb-3">
                    <label class="form-label">Genre</label>
                    <input type="text" class="form-control" name="genre" value="<?php echo htmlspecialchars($movie['genre']); ?>">
                </div>

                <div class="mb-3">
                    <label class="form-label">Status</label>
                    <select class="form-select" name="status" required>
                        <option value="Watched" <?php if ($movie['status'] == 'Watched') echo 'selected'; ?>>Watched</option>
                        <option value="Not Watched" <?php if ($movie['status'] == 'Not Watched') echo 'selected'; ?>>Not Watched</option>
                    </select>
                </div>

                <div class="mb-3">
                    <label class="form-label">Rating (1–5)</label>
                    <input type="number" class="form-control" name="rating" min="1" max="5" value="<?php echo $movie['rating']; ?>">
                </div>

                <div class="mb-3">
                    <label class="form-label">Notes</label>
                    <textarea class="form-control" name="notes" rows="3"><?php echo htmlspecialchars($movie['notes']); ?></textarea>
                </div>

                <div class="mb-3">
                    <label class="form-label">Watch Link</label>
                    <input type="url" class="form-control" name="link" value="<?php echo htmlspecialchars($movie['link']); ?>">
                </div>

                <div class="mb-3">
                    <label class="form-label">Poster Image URL</label>
                    <input type="url" class="form-control" name="image_url" value="<?php echo htmlspecialchars($movie['image_url']); ?>">
                </div><button type="submit" class="btn-submit">Update Movie</button>
            </form>

            <a href="dashboard.php" class="back-link mt-3 d-block">← Back to Dashboard</a>
        </div>
    </div>
</body>
</html>