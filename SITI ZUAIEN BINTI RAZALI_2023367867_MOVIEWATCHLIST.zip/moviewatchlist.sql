-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 17, 2025 at 11:34 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `moviewatchlist`
--

-- --------------------------------------------------------

--
-- Table structure for table `movies`
--

CREATE TABLE `movies` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `genre` varchar(100) NOT NULL,
  `status` enum('Watched','Not Watched') NOT NULL,
  `rating` int(11) NOT NULL,
  `notes` text DEFAULT NULL,
  `poster` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `year` int(11) DEFAULT NULL,
  `link` varchar(255) DEFAULT NULL,
  `image_url` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `movies`
--

INSERT INTO `movies` (`id`, `user_id`, `title`, `genre`, `status`, `rating`, `notes`, `poster`, `created_at`, `year`, `link`, `image_url`) VALUES
(1, 1, 'Racun Sangga', 'Mystic', 'Watched', 5, 'Must watch again', NULL, '2025-04-28 15:06:41', NULL, 'https://www.imdb.com/title/tt33047499/?ref_=nv_sr_srsg_0_tt_1_nm_0_in_0_q_racun%2520sangga', 'https://m.media-amazon.com/images/M/MV5BMzQ3YzEyMjAtZDNhNC00MjQ1LTgxOWItNTNkMGMwZjA4NDBhXkEyXkFqcGc@._V1_.jpg'),
(2, 3, 'Spider-Man 4: Brand New Day', 'Action', 'Not Watched', 0, 'MUST WATCH AT CINEMA LATERRRR', NULL, '2025-04-30 05:09:27', NULL, '', 'https://m.media-amazon.com/images/M/MV5BOTkwZmNmOTYtYjY1Mi00YjkzLThmODQtZjgyZDk5ODliMDNiXkEyXkFqcGc@._V1_.jpg'),
(3, 3, 'Pabrik Gula', 'Horror', 'Watched', 5, 'There\'s are cut scene, must watch again the uncut scene later hehe', NULL, '2025-04-30 05:11:50', NULL, 'https://www.imdb.com/title/tt33349807/', 'https://poster.gsc.com.my/2025/250324_PabrikGula_big.jpg'),
(5, 3, 'IPAR ADALAH MAUT', 'Romance', 'Watched', 5, 'so good', NULL, '2025-05-17 04:54:34', NULL, 'https://www.netflix.com/my-en/title/81773024', 'https://m.media-amazon.com/images/M/MV5BNDRjYTA2MzgtYWI3My00YmFjLTk1MjgtYTkwZDkyMzg1OWVjXkEyXkFqcGc@._V1_FMjpg_UX1000_.jpg'),
(6, 3, 'Laura', 'Drama', 'Watched', 3, 'sad', NULL, '2025-05-17 05:10:55', NULL, 'https://www.imdb.com/title/tt31031881/', 'https://m.media-amazon.com/images/M/MV5BODdhMmZmZmEtY2I5Ni00YmNkLTljY2ItZTlmN2QwOGQyMjAyXkEyXkFqcGc@._V1_FMjpg_UX1000_.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `email`, `password`, `created_at`) VALUES
(1, 'zuaienrazali@gmail.com', '$2y$10$eZqpAaxxRwBerUz.g.K4Ie.bHVoji2G70BHp73MWpyHtJLgVb3a2m', '2025-04-28 15:03:38'),
(3, 'Imranalias@gmail.com', '$2y$10$cmr2rCWwOkgPPsH7Sc5XguRQ/fMDALbAUlBOJf6FPJNwB4UehzOHK', '2025-04-30 05:07:29'),
(4, 'najwaa@gmail.com', '$2y$10$dJ7aelJGMEN1H0/FdSQ.TuTUsx32R7DTuG2MOEYF0zz8xWFwkDp.6', '2025-05-13 20:46:09'),
(5, 'fatinnajwa@gmail.com', '$2y$10$D5I2U8P62RMo4asOleU49utr.RP.R.wlUz9Y6j27qdUbftRRm7Q6O', '2025-05-16 05:13:54'),
(6, 'wawa@gmail.com', '$2y$10$LNYmUHxCeTnJ/YMcJCna2.hyzD42Ol1ULhN6lClBqkhIqr6UDWeBa', '2025-05-17 09:06:43');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `movies`
--
ALTER TABLE `movies`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `movies`
--
ALTER TABLE `movies`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
