<?php
// delete_movie.php

session_start();  // Start session to check login

// Redirect if not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

include('db.php'); // Use your actual DB connection file

$error_message = "";
$success = false;

// Check if movie ID is passed
if (isset($_GET['id'])) {
    $movie_id = $_GET['id'];

    // Prepare secure delete query
    $sql = "DELETE FROM movies WHERE id = ? AND user_id = ?"; // Ensures only user's movie can be deleted

    if ($stmt = $conn->prepare($sql)) {
        $stmt->bind_param("ii", $movie_id, $_SESSION['user_id']);

        if ($stmt->execute()) {
            $success = true;
        } else {
            $error_message = "Error deleting movie: " . $conn->error;
        }

        $stmt->close();
    } else {
        $error_message = "Error preparing the statement: " . $conn->error;
    }
} else {
    $error_message = "No movie ID provided.";
}
if (isset($conn)) {
        $conn->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delete Movie</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #1a1a1a;
            color: white;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 600px;
            margin: 50px auto;
            padding: 20px;
            background-color: #2e2e2e;
            border-radius: 8px;
            text-align: center;
        }
        h1 {
            color: #9b59b6;
        }
        .message {
            background-color: #34495e;
            padding: 20px;
            border-radius: 8px;
            margin-top: 20px;
        }
        .error {
            background-color: #e74c3c;
            color: #fff;
        }
        .success {
            background-color: #2ecc71;
            color: #fff;
        }
        a {
            color: #9b59b6;
            text-decoration: none;
            font-weight: bold;
        }
        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

<div class="container">
    <h1>Delete Movie</h1>

    <?php if ($error_message): ?>
        <div class="message error"><?php echo $error_message; ?></div>
        <p><a href="dashboard.php">Back to Dashboard</a></p>
    <?php elseif ($success): ?>
        <div class="message success">
            <p>Movie deleted successfully.</p>
            <p><a href="dashboard.php">Go back to your Dashboard</a></p>
        </div>
    <?php endif; ?>
</div>

</body>
</html>