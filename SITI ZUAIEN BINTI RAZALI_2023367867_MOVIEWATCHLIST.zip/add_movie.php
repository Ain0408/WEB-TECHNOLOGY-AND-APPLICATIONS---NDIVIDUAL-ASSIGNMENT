<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit;
}

$message = '';


if ($_SERVER["REQUEST_METHOD"] == "POST") {
 
    $title = trim($_POST['title']);
    $genre = trim($_POST['genre']);
    $status = $_POST['status'];
    $rating = $_POST['rating'] ?? null;
    $notes = trim($_POST['notes']);
    $link = trim($_POST['link']);
    $image_url = trim($_POST['image_url'] ?? '');
    $user_id = $_SESSION['user_id'];

    if (empty($title)) {
        $message = "Movie title is required.";
    } else {
        $sql = "INSERT INTO movies (user_id, title, genre, status, rating, notes, link, image_url) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "isssisss", $user_id, $title, $genre, $status, $rating, $notes, $link, $image_url);

        if (mysqli_stmt_execute($stmt)) {
            header("Location: dashboard.php");
            exit;
        } else {
            $message = "Error adding movie.";
        }
    }
}


$recommendations = [];

$recommend_sql = "SELECT title, genre, status, rating, notes, link, image_url FROM movies WHERE user_id != ? ORDER BY RAND() LIMIT 3";
if ($recommend_stmt = mysqli_prepare($conn, $recommend_sql)) {
    mysqli_stmt_bind_param($recommend_stmt, "i", $_SESSION['user_id']);
    mysqli_stmt_execute($recommend_stmt);
    $recommend_result = mysqli_stmt_get_result($recommend_stmt);

    if ($recommend_result) {
        while ($row = mysqli_fetch_assoc($recommend_result)) {
            $recommendations[] = $row;
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Add Movie - Movie Watchlist</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css" />
</head>
<body>
<div class="addmovie-container">
    <h2>Add New Movie</h2>

    <?php if ($message): ?>
        <div class="alert alert-danger"><?php echo $message; ?></div>
    <?php endif; ?>

    <form method="POST" action="">
        <div class="mb-3">
            <label for="title" class="form-label">Movie Title</label>
            <input type="text" class="form-control" name="title" required>
        </div>

        <div class="mb-3">
            <label for="genre" class="form-label">Genre</label>
            <input type="text" class="form-control" name="genre">
        </div>

        <div class="mb-3">
            <label class="form-label">Status</label>
            <select class="form-select" name="status" required>
                <option value="Watched">Watched</option>
                <option value="Not Watched">Not Watched</option>
            </select>
        </div>

        <div class="mb-3">
            <label for="rating" class="form-label">Rating (1–5)</label>
            <input type="number" class="form-control" name="rating" min="1" max="5">
        </div>

        <div class="mb-3">
            <label for="notes" class="form-label">Notes</label>
            <textarea class="form-control" name="notes" rows="3"></textarea>
        </div>

        <div class="mb-3">
            <label for="link" class="form-label">Watch Link (optional)</label>
            <input type="url" class="form-control" id="link" name="link" placeholder="https://www.netflix.com/..." />
        </div>

        <div class="mb-3">
            <label for="image_url" class="form-label">Poster Image URL (optional)</label>
            <input type="url" class="form-control" id="image_url" name="image_url" placeholder="https://..." />
        </div>

        <button type="submit" class="btn-submit">Add Movie</button>
    </form>

    <a href="dashboard.php" class="back-link">← Back to Dashboard</a>

    <hr class="my-4">

    <h4>Recommended by Other Users:</h4>

    <?php if (!empty($recommendations)): ?>
        <?php foreach ($recommendations as $rec): ?>
            <div class="recommendation">
                <?php if (!empty($rec['image_url'])): ?>
                    <img src="<?php echo htmlspecialchars($rec['image_url']); ?>" alt="Poster for <?php echo htmlspecialchars($rec['title']); ?>">
                <?php endif; ?>
                <div class="recommendation-details">
                    <h5><?php echo htmlspecialchars($rec['title']); ?> (<?php echo htmlspecialchars($rec['genre']); ?>)</h5>
                    <p>Status: <?php echo htmlspecialchars($rec['status']); ?></p>
                    <p>Rating: <?php echo $rec['rating'] ? str_repeat('★', $rec['rating']) : '–'; ?></p>
                    <p><?php echo nl2br(htmlspecialchars($rec['notes'])); ?></p>

                    <form method="POST" action="">
                        <input type="hidden" name="title" value="<?php echo htmlspecialchars($rec['title']); ?>">
                        <input type="hidden" name="genre" value="<?php echo htmlspecialchars($rec['genre']); ?>">
                        <input type="hidden" name="status" value="<?php echo htmlspecialchars($rec['status']); ?>">
                        <input type="hidden" name="rating" value="<?php echo $rec['rating']; ?>">
                        <input type="hidden" name="notes" value="<?php echo htmlspecialchars($rec['notes']); ?>">
                        <input type="hidden" name="link" value="<?php echo htmlspecialchars($rec['link']); ?>">
                        <input type="hidden" name="image_url" value="<?php echo htmlspecialchars($rec['image_url']); ?>">
                        <button type="submit" class="btn-recommend">Add This Movie to Mine</button>
                    </form>
                </div>
            </div>
        <?php endforeach; ?>
    <?php else: ?>
        <p>No recommendations found from other users.</p>
    <?php endif; ?>
</div>
</body>
</html>